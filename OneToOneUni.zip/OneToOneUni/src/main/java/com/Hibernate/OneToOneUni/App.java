package com.Hibernate.OneToOneUni;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.Hibernate.OneToOneUni.config.HibernateConfig;
import com.Hibernate.OneToOneUni.entity.Address;
import com.Hibernate.OneToOneUni.entity.Student;

/**
 * Hello world!
 *
 */
public class App 
{
	private static SessionFactory factory = HibernateConfig.getSessionFactory();
	
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        insertData();
        //deleteData();
    }
    
    public static void insertData() {
    	try {

			// create the objects
    		Session session=factory.openSession();
			Student tempStudent = new Student("Aakash", "Gupta", "AakashGupta@greatlearning.com");

			Address tempAddress = new Address("Haryana","Chandigarh");

			// associate the objects
			tempStudent.setStudentAddress(tempAddress);
		

			// start transaction
			session.beginTransaction();

			// save the teacher
			session.save(tempStudent);
			

			// commit transaction
			session.getTransaction().commit();

		} finally {
			factory.close();
		}
    }
    
    
    public static void deleteData() {
    	try {
    		
    		Session session=factory.openSession();
			int theStudentId=1;
			
			// start transaction
			session.beginTransaction();

			Student tempStudent = session.get(Student.class,theStudentId);
			
			if(tempStudent!=null) {
				System.out.println("Deleting : "+ tempStudent);
				
				//Note!! : it will also delete TeacherDetails data 
			    //         as we have provided CascadeType.ALL
				session.delete(tempStudent);
			}
			
			// commit transaction
			session.getTransaction().commit();

		} finally {
			factory.close();
		}
	}
}
