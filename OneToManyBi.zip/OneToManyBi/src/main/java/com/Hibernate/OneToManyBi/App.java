package com.Hibernate.OneToManyBi;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.Hibernate.OneToManyBi.config.HibernateConfig;
import com.Hibernate.OneToManyBi.entity.Course;
import com.Hibernate.OneToManyBi.entity.Student;

/**
 * Hello world!
 *
 */
public class App 
{
	private static SessionFactory factory = HibernateConfig.getSessionFactory();
	
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        insertData();
        //deleteData();
    }
    
    public static void insertData() {
try {
			
			// start transaction
			Session session=factory.openSession();
			session.beginTransaction();

			// create the objects
			Student tempStudent = new Student("Aakash", "Gupta", "AakashGupta@greatlearning.com");
			
			Course course1 = new Course("Python");
			Course course2 = new Course("Java");
			
			tempStudent.add(course1);
			tempStudent.add(course2);
		
			// save the student
			session.save(tempStudent);
			
			//save the course
			session.save(course1);
			session.save(course2);
			

			// commit transaction
			session.getTransaction().commit();
			
			System.out.println("Completed Successfully");

		} finally {
			factory.close();
		}
    }
    
    public static void deleteData() {
    	try {
    		Session session=factory.openSession();
			int theCourseId=2;
			
			// start transaction
			session.beginTransaction();

			Course tempCourse = session.get(Course.class,theCourseId);
			
			if(tempCourse!=null) {
				System.out.println("Deleting : "+ tempCourse);
				
				//Note!! : it will not delete Student data 
			    //         as we have not provided CascadeType.ALL
				session.delete(tempCourse);
			}
			
			

			// commit transaction
			session.getTransaction().commit();

		} finally {
			factory.close();
		}

    }
}