package com.Hibernate.OneToOneBi;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.Hibernate.OneToOneBi.entity.Address;
import com.Hibernate.OneToOneBi.entity.Student;
import com.Hibernate.OneToOneBi.config.HibernateConfig;

/**
 * Hello world!
 *
 */
public class App 
{
	private static SessionFactory factory = HibernateConfig.getSessionFactory();
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        insertData();
        //deleteData();
        //readData();
    }
    
    public static void insertData() {
    	try {

			// create the objects
    		Session session=factory.openSession();
			Student tempStudent = new Student("Aakash", "Gupta", "AakashGupta@greatlearning.com");

			Address tempAddress = new Address("Haryana","Chandigarh");

			// associate the objects
			tempStudent.setStudentAddress(tempAddress);
		

			// start transaction
			session.beginTransaction();

			// save the student
			session.save(tempStudent);
			

			// commit transaction
			session.getTransaction().commit();

		} finally {
			factory.close();
		}
    }
    
    public static void deleteData() {
    	try {
    		Session session=factory.openSession();
			int theAddressId=2;
			
			// start transaction
			session.beginTransaction();

			Address tempAddress = session.get(Address.class,theAddressId);
			
			if(tempAddress!=null) {
				System.out.println("Deleting : "+ tempAddress);
				
				//Note!! : it will also delete student data 
			    //         as we have provided CascadeType.ALL
				session.delete(tempAddress);
			}
			
			// commit transaction
			session.getTransaction().commit();

		} finally {
			factory.close();
		}
    }
    
    public static void readData() {
    	try {

			// start transaction
    		Session session=factory.openSession();
			session.beginTransaction();
			
			// get the address object
			int tempAddressId=2;
			Address tempAddress=session.get(Address.class, tempAddressId);

			
			// Print the Address
			System.out.println("Address Details : "+tempAddress);
						
			//print the associated student values
			System.out.println("Associated Student : "+ tempAddress.getStudent());
			

			// commit transaction
			session.getTransaction().commit();

		} finally {
			factory.close();
		}

    }
    
}
