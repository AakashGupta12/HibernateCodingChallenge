package com.Hibernate.ManyToMany;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.Hibernate.ManyToMany.config.HibernateConfig;
import com.Hibernate.ManyToMany.entity.Employee;
import com.Hibernate.ManyToMany.entity.Project;

/**
 * Hello world!
 *
 */
public class App 
{
	
	private static SessionFactory factory = HibernateConfig.getSessionFactory();
	
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        insertData();
        //fetchData();
    }
    
    public static void insertData() {
    	
    	try {	
			// start transaction
			Session session=factory.openSession();
			session.beginTransaction();

			// create the objects
			Employee tempEmployee1 = new Employee("Aakash", "Gupta", "AakashGupta@greatlearning.com");
			
			Employee tempEmployee2 = new Employee("Ujjawal", "Sharma", "UjjawalSharma@greatlearning.com");
			
			Project project1 = new Project("CustomerSupport");
			Project project2 = new Project("DataAnalysis");
			
			session.save(project1);
			session.save(project2);
			
			
			Set<Project> projectList1=new HashSet<>();
			projectList1.add(project1);
			projectList1.add(project2);
			
			tempEmployee1.setProjects(projectList1);
			

			// save the Employee
			session.save(tempEmployee1);
			
			Set<Project> projectList2=new HashSet<>();
			projectList2.add(project1);
			
			tempEmployee2.setProjects(projectList2);
			// save the Employee
			session.save(tempEmployee2);

			// commit transaction
			session.getTransaction().commit();
			
			System.out.println("Completed Successfully");

		} finally {
			factory.close();
		}

    }
    
    public static void fetchData() {
    	try {
    		Session session=factory.openSession();
			int theProjectId=1;
			
			// start transaction
			session.beginTransaction();

			Project tempProject = session.get(Project.class,theProjectId);
			
			System.out.println("Project is: "+tempProject);
			System.out.println("Assigned Employee are: "+tempProject.getEmployees());
			
			System.out.println();
			
			int theEmployeeId=3;
			Employee tempEmployee=session.get(Employee.class,theEmployeeId);
			System.out.println("Employee is: "+tempEmployee);	
			
			// commit transaction
			session.getTransaction().commit();

		} finally {
			factory.close();
		}
    }
}
